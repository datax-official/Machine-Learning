PCA code Kaggle notebook : https://www.kaggle.com/nitsin/pca-demo-1
Video Link:https://youtu.be/tXXnxjj2wM4
