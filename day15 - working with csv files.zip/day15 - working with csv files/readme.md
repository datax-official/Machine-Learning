Video link : https://www.youtube.com/watch?v=a_XrmKlaGTs

Books dataset link : http://www2.informatik.uni-freiburg.de/~cziegler/BX/
